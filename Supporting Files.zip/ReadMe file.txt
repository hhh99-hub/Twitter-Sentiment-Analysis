Open the ipynb file.
Uplpoad the testing and training dataset.
Run all cells.
Github Link: https://github.com/hhh99-hub/Twitter-Sentiment-Analysis